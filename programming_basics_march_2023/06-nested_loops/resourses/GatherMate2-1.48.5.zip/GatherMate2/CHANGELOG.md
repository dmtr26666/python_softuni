# GatherMate2

## [1.48.5](https://github.com/Nevcairiel/GatherMate2/tree/1.48.5) (2023-03-22)
[Full Changelog](https://github.com/Nevcairiel/GatherMate2/compare/1.48.4...1.48.5) [Previous Releases](https://github.com/Nevcairiel/GatherMate2/releases)

- Update TOC for 10.0.7  
