# GatherMate2

## [1.47-classic](https://github.com/Nevcairiel/GatherMate2/tree/1.47-classic) (2023-01-18)
[Full Changelog](https://github.com/Nevcairiel/GatherMate2/compare/1.46.4-classic...1.47-classic) [Previous Releases](https://github.com/Nevcairiel/GatherMate2/releases)

- Update TOC  
- Tracking functions moved into C\_Minimap  
- Clamp pin alpha to 0 instead of going negative  
